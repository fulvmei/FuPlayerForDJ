package com.chengfu.android.fuplayer.achieve.dj.demo.video.ui.video;

import android.view.ViewGroup;

public interface IGetVideoContainer {
    ViewGroup getVideoContainer();
}
