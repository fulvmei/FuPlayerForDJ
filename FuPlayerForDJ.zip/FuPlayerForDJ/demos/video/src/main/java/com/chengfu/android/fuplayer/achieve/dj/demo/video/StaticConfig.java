package com.chengfu.android.fuplayer.achieve.dj.demo.video;

public class StaticConfig {
    public static  boolean PLAY_VIDEO_NO_WIFI = false;
}
