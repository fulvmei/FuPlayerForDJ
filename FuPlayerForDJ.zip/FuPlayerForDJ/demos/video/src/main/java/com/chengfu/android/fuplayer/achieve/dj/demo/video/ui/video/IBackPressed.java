package com.chengfu.android.fuplayer.achieve.dj.demo.video.ui.video;

public interface IBackPressed {
    boolean onBackPressed();
}
